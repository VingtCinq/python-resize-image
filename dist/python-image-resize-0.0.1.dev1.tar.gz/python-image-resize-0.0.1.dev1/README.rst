A python package to easily resize images
========================================

This package gives function for easily resizing images.

The following functions are supported :

    1. resize_cover 
    2. resize_contain 
    3. resize_by_width 
    4. resize_by_height 
    5. crop 